#!/bin/bash
feh --bg-scale ~/Pictures/wallpaper.jpg &
picom --config ~/.config/picom.conf &
tint2 &
